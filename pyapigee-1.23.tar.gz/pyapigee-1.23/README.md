
**

## pyapigee - Module for apigee maintenance

**

### functions:

#### - init

    apigee(method,mgmtserver,mgmtport,adminuser,adminpw)

	method - http or https
	mgmtserver - the Managment Server
	mgmtport - the Managment Port
	adminuser - the sysadmin user of the apigee installation
	adminpw - the password

    return - the apigee object

#### - createOrg

    apigee.createOrg(name)

    create a new organization named name

    mame - name of the organization

#### - associateOrg

    apigee.createOrg(name,pod)

    associate a organization on apod

    name - name of the organization
    pod - pod to associate, default is gateway
    region - region, default is dc-1

#### - addAdmin

    apigee.addUser(org,name)
    add a adminuser to a organization

    org - organization
    name - email of the adminuser, user must be exists

#### - disassociateOrg

#### - deleteOrg

#### - addEnv

#### - delEnv

#### - getEnv

#### - addAdmin

#### - delAdmin

#### - addVirtualHost

#### - delVirtualHost

#### - addUser

#### - deleteUser

#### - addAnalytics

#### - addAnalyticGroup

#### - addToAnalytics

#### - createKeystore

#### - createKeyAlias

#### - deleteKeystore

#### - deleteKeyAlias




  

Version History:
|||
|--|--|
|1.0|  First release|	
|1.1|  Add documentation
