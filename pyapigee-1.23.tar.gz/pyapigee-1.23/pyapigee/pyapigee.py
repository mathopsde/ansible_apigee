import requests
import json


class apigee:
    def __init__(self, method, mgmt_server, mgmt_port, username, password):
        self.mgmt_server = mgmt_server
        self.mgmt_port = mgmt_port
        self.username = username
        self.password = password
        self.auth = (username, password)

        if method == 'http':
            self.methodpre = 'http://'
        elif method == 'https':
            self.methodpre = 'https://'

        url = self.methodpre + self.mgmt_server + ":" + \
            self.mgmt_port + "/v1/servers?pod=gateway&type=router"
        response = requests.get(url, auth=self.auth)
        self.router = json.loads(response.text)

        url = self.methodpre + self.mgmt_server + ":" + self.mgmt_port + \
            "/v1/servers?pod=gateway&type=message-processor"
        response = requests.get(url, auth=self.auth)
        self.message_processor = json.loads(response.text)

        url = self.methodpre + self.mgmt_server + ":" + self.mgmt_port + \
            "/v1/servers?pod=central&type=qpid-server"
        response = requests.get(url, auth=self.auth)
        self.qpid = json.loads(response.text)

        url = self.methodpre + self.mgmt_server + ":" + self.mgmt_port + \
            "/v1/servers?pod=analytics&type=postgres-server"
        response = requests.get(url, auth=self.auth)
        self.postgres = json.loads(response.text)

    def createOrgFull(self, org, env, admin, vh, vh_alias, vh_port, pod='gateway', region='dc-1'):
        self.createOrg(org)
        self.associateOrg(org, pod, region)
        self.addEnv(org, env)
        self.addVirtualHost(vh, org, env, vh_alias, vh_port)
        self.addAnalytics(org, env)

    def createOrg(self, name):
        url = self.methodpre + self.mgmt_server + \
            ':' + self.mgmt_port + '/v1/organizations'
        data = "<Organization name=\"" + name + "\" type=\"paid\" />"
        headers = {"Content-Type": "application/xml"}
        response = requests.post(
            url, data=data, auth=self.auth, headers=headers)
        return response

    def associateOrg(self, name, pod='gateway', region='dc-1'):
        url = self.methodpre + self.mgmt_server + ':' + \
            self.mgmt_port + '/v1/organizations/' + name + '/pods'
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = 'region=' + region + '&pod=' + pod
        response = requests.post(
            url, data=data, auth=self.auth, headers=headers)
        return response

    def disassociateOrg(self, name, pod='gateway', region='dc-1'):
        url = self.methodpre + self.mgmt_server + ':' + \
            self.mgmt_port + '/v1/organizations/' + name + '/pods'
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = 'action=remove&region=' + region + '&pod=' + pod
        response = requests.post(
            url, data=data, auth=self.auth, headers=headers)
        return response

    def deleteOrg(self, name):
        url = self.methodpre + self.mgmt_server + ':' + \
            self.mgmt_port + '/v1/organizations/' + name
        response = requests.delete(url, auth=self.auth)
        return response

    def addEnv(self, org, name):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + '/environments'
        headers = {"Content-Type": "application/xml"}
        data = "<Environment name=\"" + name + "\" />"
        response = requests.post(
            url, data=data, auth=self.auth, headers=headers)
        return response

    def deleteEnv(self, org, name):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + '/environments/' + name
        response = requests.delete(url, auth=self.auth)
        return response

    def getEnv(self, org):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + "/environments/"
        response = requests.get(url, auth=self.auth)
        environments = json.loads(response.text)
        return environments

    def addAdmin(self, org, name):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + '/users/' + name + '/userroles/'
        headers = {"Content-Type": "application/xml"}
        data = '<Roles><Role name="orgadmin"/></Roles>'
        response = requests.post(
            url, data=data, auth=self.auth, headers=headers)
        return response

    def addVirtualHost(self, name, org, env, alias, port):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + "/environments/" + env + "/virtualhosts"
        headers = {"Content-Type": "application/xml"}
        data = "<VirtualHost name=\"" + name + "\"> <HostAliases> <HostAlias>" + alias + \
            "</HostAlias> </HostAliases> <Interfaces/> <Port>" + port + "</Port> </VirtualHost>"
        response = requests.post(
            url, auth=self.auth, headers=headers, data=data)
        return response

    def delVirtualHost(self, name, org, env):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + "/environments/" + env + "/virtualhosts/" + name
        response = requests.delete(url, auth=self.auth)

    def addUser(self, lastname, firstname, password, email):
        url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + "/v1/users"
        data = "<User> <FirstName>" + firstname + "</FirstName><LastName>" + lastname + \
            "</LastName><Password>" + password + \
            "</Password><EmailId>" + email + "</EmailId></User>"
        headers = {"Content-Type": "application/xml"}
        response = requests.post(url, headers=headers,
                                 auth=self.auth, data=data)
        return response

    def deleteUser(self, email):
        url = url = self.methodpre + self.mgmt_server + \
            ':' + self.mgmt_port + "/v1/users/" + email
        response = requests.delete(url, auth=self.auth)
        return response

    def getRouteruUID(self, server):
        url = self.methodpre + server + ":8081/v1/servers/self"
        response = requests.get(url)
        content = json.loads(response.content)
        return content['uUID']

    def getMPuUID(self, server):
        url = self.methodpre + server + ":8082/v1/servers/self"
        response = requests.get(url)
        content = json.loads(response.content)
        return content['uUID']

    def getRouteruUIDs(self):
        routers = []
        for router in self.router:
            routers.append(router['uUID'])
        return routers

    def getMPuUIDs(self):
        mps = []
        for mp in self.message_processor:
            mps.append(mp['uUID'])
        return mps

    def getPostgresuUIDs(self):
        pgs = []
        for pg in self.postgres:
            pgs.append(pg['uUID'])
        return pgs

    def getQpiduUIDs(self):
        qps = []
        for qp in self.qpid:
            qps.append(qp['uUID'])
        return qps

    def addAnalytics(self, org, env):
        qpid = '\"' + '\",\"'.join(self.getQpiduUIDs()) + '\"'
        postgres = '\"' + '\",\"'.join(self.getPostgresuUIDs()) + '\"'
        jsonvar = "{ \
            \"properties\" : { \
            \"samplingAlgo\" : \"reservoir_sampler\", \
            \"samplingTables\" : \"10=ten;1=one;\", \
            \"aggregationinterval\" : \"300000\", \
            \"samplingInterval\" : \"300000\", \
            \"useSampling\" : \"100\", \
            \"samplingThreshold\" : \"100000\" \
            }, \
                \"servers\" : { \
                    \"postgres-server\" : [ " + postgres + " ],  \
                    \"qpid-server\" : [ " + qpid + "] \
            } \
        }"
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            '/v1/organizations/' + org + "/environments/" + env + "/analytics/admin"
        headers = {"Content-Type": "application/json"}
        response = requests.post(
            url, auth=self.auth, headers=headers, data=jsonvar)
        return response

    def addAnalyticGroup(self, name, cgname, region='dc-1'):
        qpid = '.'.join(self.getQpiduUIDs())
        postgres = '.'.join(self.getPostgresuUIDs())

        url = url = url = self.methodpre + self.mgmt_server + ':' + \
            self.mgmt_port + "/v1/analytics/groups/ax/" + name
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, auth=self.auth, headers=headers)

        url = url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/" + name + "consumer-groups?name=" + cgname
        headers = {"Content-Type": "application/json",
                   "Accept": "application/json"}
        response = requests.post(url, auth=self.auth, headers=headers)

        url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/axgroupNew/properties?propName=consumer-type&propValue=ax"
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, headers=headers, auth=self.auth)

        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/" + name + \
            "/properties?propName=region&propValue=" + region
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, headers=headers, auth=self.auth)

        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/axgroupNew/servers?uuid=" + \
            postgres + "&type=postgres-server&force=true"
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, headers=headers, auth=self.auth)

        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/axgroupNew/consumer-groups/" + \
            cgname + "/datastores?uuid=" + postgres
        headers = {"Content-Type": "application/json",
                   "Accept": "application/json"}
        response = requests.post(url, headers=headers, auth=self.auth)

        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/axgroupNew/consumer-groups/" + \
            cgname + "/consumers?uuid=" + qpid
        headers = {"Content-Type": "application/json",
                   "Accept": "application/json"}
        response = requests.post(url, headers=headers, auth=self.auth)

    def addToAnalytics(self, org, env):
        url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/analytics/groups/ax/axgroupNew/scopes?org=" + org + "&env=" + env
        headers = {"Content-Type": "application/json"}
        response = requests.post(url, headers=headers, auth=self.auth)

    def createKeystore(self, org, env, name):
        url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/o/" + org + "/e/" + env + "/keystores"
        headers = {"Content-Type": "text/xml"}
        data = "<KeyStore name=\"" + name + "\" /"
        response = requests.post(url, headers=headers,
                                 auth=self.auth, data=data)

    def createKeyAlias(self, org, env, keystore, name, cert, key, keypwd=''):
        url = url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/o/" + org + "/e/" + env + "/keystores/" + keystore + \
            "/aliases?alias=" + name + "&format=keycertfile"
        files = {'certfile': open(cert, 'rb'), 'keyfile': open(key, 'rb')}
        headers = {"Content-Type": "multipart/form-data"}
        data = {'password': keypwd}
        response = requests.post(url, headers=headers,
                                 auth=self.auth, files=files, data=data)

    def deleteKeystore(self, org, env, name):
        url = url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "https://api.enterprise.apigee.com/v1/o/" + \
            org + "/e/" + env + "/keystores/" + name
        response = requests.delete(url, auth=self.auth)

    def deleteKeyAlias(self, org, env, keystore, name):
        url = url = url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "https://api.enterprise.apigee.com/v1/o/" + org + "/e/" + \
            env + "/keystores/" + keystore + "/aliases/" + name
        response = requests.delete(url, auth=self.auth)

    def registerRouter(self):
        Null

    def registerMessageProcessor(self):
        Null

    def unregisterRouter(self):
        Null

    def unregisterMessageProcessor(self):
        Null

    def createCustomRole(self, rolename, org):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/organizations/" + org + "/userroles"
        headers = {"Content-Type": "application/json"}
        data = "{ \"role\" : [ { \"name\" : \"" + rolename + "\" } ] }"
        response = requests.post(
            url, data=data, headers=headers, auth=self.auth)
        return response

    def addPermissionsToRole(self, org, role):
        url = self.methodpre + self.mgmt_server + ':' + self.mgmt_port + \
            "/v1/organizations/" + org + "/userroles/" + role + "/permissions"
        data = {}

    def addUserToRole(self):
        Null

    def deleteUserFromRole(self):
        Null
