import pyapigee as apigee

apigee = apigee.apigee('http','apigee01.mathops.de','8080','mpaezolt@gmail.com','MnLwYdkBfiFG1zH60WFL')
test = apigee.addAdmin('ohb','sitaro@me.com')
# apigee.associateOrg('Polux','gateway')
# apigee.addEnv('Polux','Dev')
# apigee.addAdmin('Polux','sitaro@me.com')

#apigee.addAnalyticGroup('test','test3')
#test = apigee.getPostgresuUIDS()
print(test)

#servers = apigee.servers('apigee01.mathops.de','8080','mpaezolt@gmail.com','MnLwYdkBfiFG1zH60WFL')